require("dotenv").config();

module.exports = {
    PORT: process.env.PORT || 5000,

    MONGO_URL: process.env.MONGO_URL,
    MONGODB_URI: process.env.MONGODB_URI,

    JWT_SECRET: process.env.JWT_SECRET,
    JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || "7d",

    CLIENT_URL: process.env.CLIENT_URL || "http://localhost:5173",
};